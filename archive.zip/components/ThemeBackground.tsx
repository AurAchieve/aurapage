'use client';

import React from 'react';
import { HackerBackground } from './backgrounds/HackerBackground';
import { PeaceBackground } from './backgrounds/PeaceBackground';
import { MidnightBackground } from './backgrounds/MidnightBackground';
import { InfernoBackground } from './backgrounds/InfernoBackground';
import { GoldBackground } from './backgrounds/GoldBackground';

interface ThemeBackgroundProps {
  theme: string;
}

export const ThemeBackground: React.FC<ThemeBackgroundProps> = ({ theme }) => {
  switch (theme) {
    case 'hacker':
      return <HackerBackground />;
    case 'peace':
      return <PeaceBackground />;
    case 'midnight':
      return <MidnightBackground />;
    case 'inferno':
      return <InfernoBackground />;
    case 'gold':
      return <GoldBackground />;
    default:
      return null;
  }
};
